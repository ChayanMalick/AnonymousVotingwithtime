export interface Candidate {
  id: string;
  name: string;
  votes: number;
}

export interface VotingState {
  candidates: Candidate[];
  hasVoted: boolean;
  votingEndTime: Date;
  isVotingEnded: boolean;
}