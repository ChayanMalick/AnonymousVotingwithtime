import React from 'react';
import { Vote } from 'lucide-react';
import { Candidate } from '../types';

interface VotingCardProps {
  candidate: Candidate;
  onVote: (candidateId: string) => void;
  disabled: boolean;
}

export const VotingCard: React.FC<VotingCardProps> = ({ candidate, onVote, disabled }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <h3 className="text-xl font-semibold mb-4">{candidate.name}</h3>
      <button
        onClick={() => onVote(candidate.id)}
        disabled={disabled}
        className={`w-full flex items-center justify-center gap-2 py-2 px-4 rounded-md text-white transition-colors ${
          disabled
            ? 'bg-gray-400 cursor-not-allowed'
            : 'bg-blue-600 hover:bg-blue-700'
        }`}
      >
        <Vote size={20} />
        Vote
      </button>
    </div>
  );
};