import React from 'react';
import { Trophy } from 'lucide-react';
import { Candidate } from '../types';

interface ResultsProps {
  candidates: Candidate[];
}

export const Results: React.FC<ResultsProps> = ({ candidates }) => {
  const sortedCandidates = [...candidates].sort((a, b) => b.votes - a.votes);
  const winner = sortedCandidates[0];
  const totalVotes = candidates.reduce((sum, candidate) => sum + candidate.votes, 0);

  return (
    <div className="space-y-6">
      <div className="bg-green-100 p-6 rounded-lg">
        <div className="flex items-center gap-2 mb-4">
          <Trophy className="text-green-600" size={24} />
          <h2 className="text-2xl font-bold text-green-800">Winner</h2>
        </div>
        <p className="text-xl text-green-700">{winner.name}</p>
        <p className="text-green-600">
          {winner.votes} votes ({((winner.votes / totalVotes) * 100).toFixed(1)}%)
        </p>
      </div>

      <div className="space-y-4">
        <h3 className="text-xl font-semibold">Final Results</h3>
        {sortedCandidates.map((candidate) => (
          <div
            key={candidate.id}
            className="bg-white p-4 rounded-lg shadow"
          >
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium">{candidate.name}</span>
              <span className="text-gray-600">
                {((candidate.votes / totalVotes) * 100).toFixed(1)}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div
                className="bg-blue-600 h-2.5 rounded-full"
                style={{
                  width: `${(candidate.votes / totalVotes) * 100}%`,
                }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};