import React from 'react';
import { Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface TimerProps {
  endTime: Date;
  onTimeEnd: () => void;
}

export const Timer: React.FC<TimerProps> = ({ endTime, onTimeEnd }) => {
  const [timeLeft, setTimeLeft] = React.useState<string>('');

  React.useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      if (now >= endTime) {
        onTimeEnd();
        clearInterval(timer);
        setTimeLeft('Voting Ended');
      } else {
        setTimeLeft(formatDistanceToNow(endTime, { addSuffix: true }));
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [endTime, onTimeEnd]);

  return (
    <div className="flex items-center gap-2 text-gray-600">
      <Clock size={20} />
      <span>{timeLeft}</span>
    </div>
  );
};