import React from 'react';
import { VotingCard } from './components/VotingCard';
import { Timer } from './components/Timer';
import { Results } from './components/Results';
import { VotingState } from './types';
import { Vote } from 'lucide-react';

function App() {
  const [state, setState] = React.useState<VotingState>({
    candidates: [
      { id: '1', name: 'Candidate A', votes: 0 },
      { id: '2', name: 'Candidate B', votes: 0 },
      { id: '3', name: 'Candidate C', votes: 0 },
    ],
    hasVoted: false,
    votingEndTime: new Date(Date.now() + 5 * 60 * 1000), // 5 minutes from now
    isVotingEnded: false,
  });

  const handleVote = (candidateId: string) => {
    setState((prev) => ({
      ...prev,
      candidates: prev.candidates.map((candidate) =>
        candidate.id === candidateId
          ? { ...candidate, votes: candidate.votes + 1 }
          : candidate
      ),
      hasVoted: true,
    }));
  };

  const handleTimeEnd = () => {
    setState((prev) => ({ ...prev, isVotingEnded: true }));
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-4xl mx-auto p-6">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            <Vote className="text-blue-600" size={32} />
            <h1 className="text-3xl font-bold text-gray-800">Anonymous Voting</h1>
          </div>
          <Timer endTime={state.votingEndTime} onTimeEnd={handleTimeEnd} />
        </div>

        {state.isVotingEnded ? (
          <Results candidates={state.candidates} />
        ) : (
          <div>
            {state.hasVoted ? (
              <div className="bg-green-100 p-4 rounded-lg mb-6">
                <p className="text-green-700 text-center">
                  Thank you for voting! Results will be displayed when the voting period ends.
                </p>
              </div>
            ) : (
              <p className="text-gray-600 mb-6">
                Cast your vote anonymously. You can only vote once.
              </p>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {state.candidates.map((candidate) => (
                <VotingCard
                  key={candidate.id}
                  candidate={candidate}
                  onVote={handleVote}
                  disabled={state.hasVoted}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;